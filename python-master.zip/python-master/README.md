# CSD's Python 3 Repo
Our python work done in class.
