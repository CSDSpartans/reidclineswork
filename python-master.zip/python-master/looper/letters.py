characters = ["H","i","a","b","c","d","e","f","g"]
characters = ["0","1"]
