class Goons():
    att = 10 #Attack
    mp = None #Magic Points
    agi = -4
    hp = 100
class Logan(Goons):
    deff = 25
    att = 15
class Sern(Logan):
    hair = "Rad"

